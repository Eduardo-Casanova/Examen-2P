CREATE DATABASE Examen;

USE Examen;

CREATE TABLE Autores (
    id INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    fecha_nacimiento DATE
);

CREATE TABLE Libros (
    id INT PRIMARY KEY IDENTITY(1,1),
    titulo VARCHAR(100) NOT NULL,
    fecha_publicacion DATE,
    autor_id INT,
    precio DECIMAL(10, 2),
    FOREIGN KEY (autor_id) REFERENCES Autores(id)
);

SELECT * FROM Autores;

SELECT * FROM Libros;