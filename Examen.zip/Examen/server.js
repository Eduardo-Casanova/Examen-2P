import express from 'express';
import bodyParser from 'body-parser';
import sql from 'mssql';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import autoresRoutes from './routes/autores.js';
import librosRoutes from './routes/libros.js';

dotenv.config();

const app = express();
const port = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_NAME,
  options: {
    encrypt: true,
    enableArithAbort: true,
    trustServerCertificate: true
  }
};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

sql.connect(dbConfig).then(pool => {
  if (pool.connected) {
    console.log('Conectado a la base de datos');
  }
}).catch(err => {
  console.error('Error de conexión:', err);
});

app.use('/autores', autoresRoutes);
app.use('/libros', librosRoutes);

// Página de inicio
app.get('/', (req, res) => {
  res.render('index'); // Renderizar la página de inicio
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
