import express from 'express';
import sql from 'mssql';

const router = express.Router();

// Listar todos los libros
router.get('/', async (req, res) => {
  const result = await sql.query`SELECT Libros.*, Autores.nombre AS autor_nombre, Autores.apellido AS autor_apellido FROM Libros JOIN Autores ON Libros.autor_id = Autores.id`;
  res.render('libros/index', { libros: result.recordset });
});

// Añadir un nuevo libro
router.get('/nuevo', async (req, res) => {
  const autores = await sql.query`SELECT * FROM Autores`;
  res.render('libros/nuevo', { autores: autores.recordset });
});

router.post('/', async (req, res) => {
  const { titulo, fecha_publicacion, autor_id, precio } = req.body;
  await sql.query`INSERT INTO Libros (titulo, fecha_publicacion, autor_id, precio) VALUES (${titulo}, ${fecha_publicacion}, ${autor_id}, ${precio})`;
  res.redirect('/libros');
});

// Editar un libro existente
router.get('/editar/:id', async (req, res) => {
  const libroResult = await sql.query`SELECT * FROM Libros WHERE id = ${req.params.id}`;
  const autores = await sql.query`SELECT * FROM Autores`;
  res.render('libros/editar', { libro: libroResult.recordset[0], autores: autores.recordset });
});

router.post('/editar/:id', async (req, res) => {
  const { titulo, fecha_publicacion, autor_id, precio } = req.body;
  await sql.query`UPDATE Libros SET titulo = ${titulo}, fecha_publicacion = ${fecha_publicacion}, autor_id = ${autor_id}, precio = ${precio} WHERE id = ${req.params.id}`;
  res.redirect('/libros');
});

// Eliminar un libro
router.get('/eliminar/:id', async (req, res) => {
  await sql.query`DELETE FROM Libros WHERE id = ${req.params.id}`;
  res.redirect('/libros');
});

import { validarLibro } from '../middlewares/validacion.js';

router.post('/', validarLibro, async (req, res) => {
  // Código para añadir libro
});

router.post('/editar/:id', validarLibro, async (req, res) => {
  // Código para editar libro
});

router.get('/buscar', async (req, res) => {
  const { query } = req.query;
  const result = await sql.query`SELECT Libros.*, Autores.nombre AS autor_nombre, Autores.apellido AS autor_apellido FROM Libros JOIN Autores ON Libros.autor_id = Autores.id WHERE Libros.titulo LIKE '%' + ${query} + '%' OR Autores.nombre LIKE '%' + ${query} + '%' OR Autores.apellido LIKE '%' + ${query} + '%'`;
  res.render('libros/index', { libros: result.recordset });
});


export default router;
