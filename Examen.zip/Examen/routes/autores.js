import express from 'express';
import sql from 'mssql';

const router = express.Router();

// Listar todos los autores
router.get('/', async (req, res) => {
  const result = await sql.query`SELECT * FROM Autores`;
  res.render('autores/index', { autores: result.recordset });
});

// Añadir un nuevo autor
router.get('/nuevo', (req, res) => {
  res.render('autores/nuevo');
});

router.post('/', async (req, res) => {
  const { nombre, apellido, fecha_nacimiento } = req.body;
  await sql.query`INSERT INTO Autores (nombre, apellido, fecha_nacimiento) VALUES (${nombre}, ${apellido}, ${fecha_nacimiento})`;
  res.redirect('/autores');
});

// Editar un autor existente
router.get('/editar/:id', async (req, res) => {
  const result = await sql.query`SELECT * FROM Autores WHERE id = ${req.params.id}`;
  res.render('autores/editar', { autor: result.recordset[0] });
});

router.post('/editar/:id', async (req, res) => {
  const { nombre, apellido, fecha_nacimiento } = req.body;
  await sql.query`UPDATE Autores SET nombre = ${nombre}, apellido = ${apellido}, fecha_nacimiento = ${fecha_nacimiento} WHERE id = ${req.params.id}`;
  res.redirect('/autores');
});

// Eliminar un autor
router.get('/eliminar/:id', async (req, res) => {
  await sql.query`DELETE FROM Autores WHERE id = ${req.params.id}`;
  res.redirect('/autores');
});

import { validarAutor } from '../middlewares/validacion.js';

router.post('/', validarAutor, async (req, res) => {
  // Código para añadir autor
});

router.post('/editar/:id', validarAutor, async (req, res) => {
  // Código para editar autor
});


export default router;

