export const validarAutor = (req, res, next) => {
  const { nombre, apellido, fecha_nacimiento } = req.body;
  if (!nombre || !apellido) {
    return res.status(400).send('Nombre y apellido son obligatorios');
  }
  next();
};

export const validarLibro = (req, res, next) => {
  const { titulo, autor_id, precio } = req.body;
  if (!titulo || !autor_id || !precio) {
    return res.status(400).send('Título, autor y precio son obligatorios');
  }
  if (isNaN(precio)) {
    return res.status(400).send('El precio debe ser un número válido');
  }
  next();
};

  